﻿using Gadgets.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Gadgets.Application.Contracts.Contexts
{
    public interface IGadgetContext
    {
        Gadget Buscar(string nombre);
    }
}
